export const data = [
  {
    src: 'https://images.unsplash.com/photo-1524492412937-b28074a5d7da?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8aW5kaWF8ZW58MHx8MHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=60',
    text: 'Hello',
  },
  {
    src: 'https://images.unsplash.com/photo-1617217139357-b77ae58ad4b2?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=889&q=80',
    text: 'Hello',
  },
  {
    src: 'https://images.unsplash.com/photo-1465919292275-c60ba49da6ae?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTV8fGluZGlhfGVufDB8fDB8fA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=60',
    text: 'Hello',
  },
];
