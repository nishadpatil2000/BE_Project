import right from '../assets/icons/right.svg';
import left from '../assets/icons/left.svg';

const icons = {
  right,
  left,
};

export default icons;
