export const MAIN = "/";
